#!/bin/bash
#
# backup_full.sh - Backup comprimido de un directorio.
# TP Integrador - Computacion Aplicada - Universidad de Palermo
#
# Uso: ./backup_full.sh <origen> <destino>

mostrar_ayuda() {
    cat <<EOF
Uso: $(basename "$0") <origen> <destino>

  <origen>    Directorio que se va a backupear.        Ej: /var/log
  <destino>   Directorio donde se guarda el backup.    Ej: /backup_dir

El archivo generado se llama <nombre_origen>_bkp_YYYYMMDD.tar.gz
Ejemplo: /var/log  ->  log_bkp_20240302.tar.gz

Opciones:
  -help, -h   Muestra esta ayuda y termina.

Ejemplos:
  $(basename "$0") /var/log /backup_dir
  $(basename "$0") /www_dir /backup_dir
EOF
}

# --- 5.5) Opcion de ayuda -------------------------------------------------
if [ "$1" = "-help" ] || [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
    mostrar_ayuda
    exit 0
fi

# --- 5.4) Argumentos ------------------------------------------------------
if [ $# -ne 2 ]; then
    echo "ERROR: se esperaban 2 argumentos y se recibieron $#." >&2
    echo "Probar: $(basename "$0") -help" >&2
    exit 1
fi

ORIGEN="${1%/}"      # saca la barra final si la tiene
DESTINO="${2%/}"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# --- 5.6) Validaciones ----------------------------------------------------
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: el directorio de origen '$ORIGEN' no existe." >&2
    exit 2
fi

if [ ! -r "$ORIGEN" ]; then
    echo "ERROR: no hay permisos de lectura sobre '$ORIGEN'." >&2
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "ERROR: el directorio de destino '$DESTINO' no existe." >&2
    exit 3
fi

if ! mountpoint -q "$DESTINO"; then
    echo "ERROR: '$DESTINO' no es un punto de montaje activo." >&2
    echo "       La particion no esta montada; se cancela el backup." >&2
    exit 3
fi

if [ ! -w "$DESTINO" ]; then
    echo "ERROR: no hay permisos de escritura sobre '$DESTINO'." >&2
    exit 3
fi

# --- Backup ---------------------------------------------------------------
echo "[$(date '+%F %T')] Backup de $ORIGEN -> $ARCHIVO"

if tar -czpf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE" 2>/dev/null; then
    echo "[$(date '+%F %T')] OK - $(du -h "$ARCHIVO" | cut -f1)"
    exit 0
else
    echo "[$(date '+%F %T')] ERROR al generar $ARCHIVO" >&2
    exit 4
fi
