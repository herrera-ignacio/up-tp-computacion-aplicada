history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
exit
lsb_release -a
apt update
ip route
ping -c 192.168.0.1
ping -c 3 192.168.0.1
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
cat /etc/resolv.conf
ip route
ping -c 192.168.1.200
ping -c 3 192.168.1.200
ping -c 3 192.168.1.50
ip a
ip route
vim /etc/network/interfaces
/etc/init.d/networking restart
ping 8.8.8.8
/etc/init.d/networking restart
/etc/init.d/networking restart
vim /etc/network/interfaces
/etc/init.d/networking restart
ping 8.8.8.8
ping -c 3 8.8.8.8
ping
ping localhost
ping 8.8.8.8
ping 192.168.1.1
ping deb.devian.org
ip route

ip link set enp0s3 up
ip route
dhclint -v enp0s3
systemctl
systemctl restart networking
iproute
ip route
ip route
vim /etc/network/interfaces
vim /etc/network/interfaces
pkill dhclient
ip addr flush dev enp0s3
ip route flush dev enp0s3
ip link set enp0s3 up
dhclient -v enp0s3
ip a show enp0s3
ip route
ping -c 3 8.8.8.8
ping 192.168.1.50
vim /etc/network/interfaces
pkill dhclient
ifdown enp0s3
ifup enp0s3
ip a show enp0s3
vim /etc/network/interfaces
pkill dhclient
ifdown enp0s3
ifup enp0s3
ip a show enp0s3
ip route
ping -c 3 192.168.1.1
vim /etc/network/interfaces
ping -c 3 deb.debian.org
ping -4 -c 3 deb.debian.org
apt update
getent hosts deb.debian.org
getent hosts cdn2-fastly.deb.debian.org
vim /etc/apt/sources.list
apt update
apt upgrade -6
apt upgrade -y
apt-get update
apt upgrade -y
vim /etc/apt/sources.list
rm -rf /var/lib/lists/*
apt update
apt upgrade -y
apt full-upgrade -y
lsb_release -a
apt install -y openssh-server
systemctl enable --now ssh
ls -la /root
ls -la /root
gzip
tar -tzvf /root/Material_Adicional_TPVMCA.tar.gz 
ls
cd /root/
ls
ls -la
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz 
ls
cat Material_Adicional_TPVMCA/clave_publica.pub 
cat Material_Adicional_TPVMCA/clave_publica.pub 
cd .ssh/
ls
ls -la
cd ..
ls
cp Material_Adicional_TPVMCA/clave_publica.pub .ssh/authorized_keys
chmod 700 .ssh/
chmod 600 .ssh/authorized_keys 
vim /etc/ssh/sshd_config
sshd -t
systemctl restart ssh
apt install -y apache2 php libapache2-mod-php
systemctl enable --now apache2
php -v
apache2ctl -M
cp Material_Adicional_TPVMCA/index.php /var/www/html/
cp Material_Adicional_TPVMCA/logo.png /var/www/html/
ls /var/www/html/
ls Material_Adicional_TPVMCA
chown -R www-data:www-data /var/www/html/
chmod 644 /var/www/html/index.php /var/www/html/logo.png 
rm -f /var/www/html/index.html 
systemctl reload apache2
curl -I http://localhost/
curl -I http://localhost/index.php
tail -n 30 /var/log/apache2/error.log 
apt install -y php-mysql
systemctl restart apache2
php -m | grep -i mysql
curl -I http://localhost/index.php
tail -n 30 /var/log/apache2/error.log 
apt install -y mariadb-server
systemctl enable --now mariadb
ls -l /run/mysqldb/mysqld.sock
ls -l /run/mysqld/mysqld.sock
sed -n '1,20p' /var/www/html/index.php 
mysql < Material_Adicional_TPVMCA/db.sql 
cat Material_Adicional_TPVMCA/db.sql 
mysql -e "SHOW DATABASES;"
mysql -u lcars -p'NCC1701D' -e "USE ingenieria; SELECT * FROM alumnos LIMIT 5;"
curl http://localhost/index.php
hostname ctl set-hostname TPServer
hostnamectl set-hostname TPServer
vim /etc/hosts
bash -l
lsblk
fdisk -l /dev/sdc
fdisk /dev/sdc
lsblk /dev/sdc
fdisk -l /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
mount /dev/sdc1 /www_dir/
mount /dev/sdc2 /backup_dir/
df -h /www_dir/ /backup_dir/
cp Material_Adicional_TPVMCA/index.php Material_Adicional_TPVMCA/logo.png /www_dir/
ls /www_dir/
chown /R www-data:www-data /www_dir/
chown -R www-data:www-data /www_dir/
chmod 755 /www_dir/
chmod 644 /www_dir/index.php /www_dir/logo.png 
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
apache2ctl configtest 
systemctl reload apache2
curl http://localhost
blkid /dev/sdc1 /dev/sdc2
vim /fstab
vim /fstab
cat /etc/fstab 
rm /fstab 
vim /etc/fstab 
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
vim /etc/fstab 
umount /www_dir /backup_dir 
mount -a
systemctl daemon-reload
mount -a
df -h | grep -E "www_dir|backup_dir"
reboot
